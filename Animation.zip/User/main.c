#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "SSD1306.h"
#include "ball.h"
#include <stdlib.h>
#include <math.h>

const static float G = 9.8f;

int main(void)
{
	OLED_Init();
    
    uint8_t x = 0;
    uint8_t y = 0;
    uint8_t prevX = x;
    uint8_t prevY = y;
    float t = 0.0f;
    uint8_t deltaY = 1;
    
    while (1) {
        prevX = x;
        prevY = y;
        
        x = (uint8_t)(G * t * t / 2 / 20 * 128);
        
        y = (uint8_t)(prevY + deltaY);
        
        if (x >= 128 || y >= 64) {
            x = 0;
            y = 0;
            t = 0.0;
            int z = rand() % 5;
            deltaY = (uint8_t)(fmax(1, z));
            continue;            
        }
        // OLED_ShowNum(1, 1, x, 4);
        // OLED_ShowNum(1, 6, y, 4);
        clearBall(prevX, prevY);
        drawBall(x, y);

        Delay_ms(50);
        t += 0.05f;
    }
}
