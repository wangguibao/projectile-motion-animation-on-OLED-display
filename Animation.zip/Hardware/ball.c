#include "SSD1306.h"
#include "ball.h"

const static int BALLWIDTH = 8;
const static int BALLHEIGHT = 8;

const static uint8_t ballData[] = {
    0x3C,0x7E,0xFF,0xFF,0xFF,0xFF,0x7E,0x3C,
    /*"D:\ball.bmp",0*/
    /* (8 X 8 )*/
};

void drawBall(uint8_t x, uint8_t y) {
    int bytes = sizeof(ballData) / sizeof(ballData[0]);

    int crossPage = 0;
    if ((y / ROWS_PER_PAGE) != (y + BALLHEIGHT) / ROWS_PER_PAGE) {
        crossPage = 1;
    }
    
    if (crossPage) {
        uint8_t firstPage = y / ROWS_PER_PAGE;
        uint8_t firstHalfBits = ROWS_PER_PAGE - (y % ROWS_PER_PAGE);
        uint8_t secondHalfBits = ROWS_PER_PAGE - firstHalfBits;
        
        OLED_SetCursor(firstPage, x);
        for (int i = 0; i < BALLWIDTH; ++i) {
            OLED_WriteData((uint8_t)(ballData[i] << secondHalfBits));
        }
        
        if (firstPage >= 7) {
            return;
        }
        OLED_SetCursor(firstPage + 1, x);
        for (int i = 0; i < BALLWIDTH; ++i) {
            OLED_WriteData(ballData[i] >> firstHalfBits);
        }
    } else {
        uint8_t page = y / ROWS_PER_PAGE;
        OLED_SetCursor(page, x);

        for (int i = 0; i < bytes; ++i) {            
            OLED_WriteData(ballData[i]);
        }
    }
}

void clearBall(uint8_t x, uint8_t y) {
    int bytes = sizeof(ballData) / sizeof(ballData[0]);

    int crossPage = 0;
    if ((y / ROWS_PER_PAGE) != (y + BALLHEIGHT) / ROWS_PER_PAGE) {
        crossPage = 1;
    }
    
    if (crossPage) {
        uint8_t firstPage = y / ROWS_PER_PAGE;
        
        OLED_SetCursor(firstPage, x);
        for (int i = 0; i < BALLWIDTH; ++i) {
            OLED_WriteData(0);
        }
        
        if (firstPage >= 7) {
            return;
        }
        
        OLED_SetCursor(firstPage + 1, x);
        for (int i = 0; i < BALLWIDTH; ++i) {
            OLED_WriteData(0);
        }
    } else {
        uint8_t page = y / ROWS_PER_PAGE;
        OLED_SetCursor(page, x);

        for (int i = 0; i < bytes; ++i) {            
            OLED_WriteData(0);
        }
    }    
}
