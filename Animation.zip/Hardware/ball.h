#ifndef BALL_H
#define BALL_H
#include <stdint.h>

void drawBall(uint8_t x, uint8_t y);
void clearBall(uint8_t x, uint8_t y);
#endif
